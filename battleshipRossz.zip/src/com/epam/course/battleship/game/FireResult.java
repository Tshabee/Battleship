package com.epam.course.battleship.game;

public enum FireResult {

	HIT,
	MISS,
	SUNK,
	WIN
}
