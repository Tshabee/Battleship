package com.epam.course.battleship.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public class IOHandler {

	private BufferedReader in;
	private PrintWriter out;
	
	IOHandler(Connector connector) throws IOException {
		this.in = connector.getInputReader();
		this.out = connector.getOutputWriter();
	}
	
	void send(Message message) throws IOException {
		System.out.println("---> " + message);
		out.println(message.toString());
		out.flush();
	}
	
	Message receive() throws IOException, InterruptedException {
		waitForInput();

		Message message = new Message(in.readLine());
		System.out.println("---> " + message);
		return message;
	}

	private void waitForInput() throws IOException, InterruptedException {
		while (!in.ready()) {
			Thread.sleep(100);
		}
	}
	
	Message receiveShips() throws IOException, InterruptedException {
		waitForInput();
		StringBuilder rawMessage = new StringBuilder();
		while (in.ready()) {
			rawMessage.append(in.readLine());
			rawMessage.append("\n");
		}
		System.out.println(rawMessage.toString());
		return new Message(rawMessage.toString().trim());
	}
}
