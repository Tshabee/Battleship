package com.epam.course.battleship.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Connector {

	private static final int PORT = 1146;
	
	public static Connector createServer() throws IOException {
		try (ServerSocket serverSocket = new ServerSocket(PORT)) {
			return new Connector(serverSocket.accept());
		}
	}
	
	public static Connector createClient(String host) throws IOException {
		return new Connector(new Socket(host, PORT));
	}
	
	private Socket socket;
	
	private Connector(Socket socket) {
		this.socket = socket;
	}
	
	BufferedReader getInputReader() throws IOException {
		return new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}
	
	PrintWriter getOutputWriter() throws IOException {
		return new PrintWriter(socket.getOutputStream());
	}
}
